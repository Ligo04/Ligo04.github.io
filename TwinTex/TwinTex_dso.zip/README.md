# Twintex

`houdini >=19.5`

## SOP_TwinTex

`C:\Users\xxx\Documents\houdini19.5\dso` directory：

```
----
 ├──SOP_TwinTex.dll
 ├──libgmp-10.dll
 ├──opencv_world460.dll
```

You can add SOP_TwinTex to the Geometry node.

![image-20230906162939471](D:\TwinTex\assets\image-20230906162939471.png)

## RUN

1. First specify the configuration file `default_config.yaml` and the path to the scene directory, which has the following structure:

   ```
   ----
    ├──Mesh
       ├──original_mesh.ply
       ├──simplify_mesh.ply
       ├──simplify_mesh_sub.ply
    ├──Scene
    ├──Results(autocreate）
   ```

2. Press the `Load Data` button to load scene data

3. (Optional) `Load Results` : Load the results of `Result\finale_result`.

4. (Optional) `Show Views`: show the position and direction of the view (only works on a single plane).

5. (Optional) `Show Image`: show the output of ViewSelection or ImageStitching (only works on a single plane).

6. `ViewSelection`: Parameters of ViewSelection and apply

7. `ImageStitching`：Parameters of ImageStitchingand apply

8. `Inpainting`:

   - `MMRP Path`： Specify the path to the MMRP project, see `MMRP\README.md` for dependency details
   - `Inpainting`:   Inpaint with Plane to be inpainted

9. `start`: ViewSelection and ImageStitching apply at the same time.

If houdini crashes, please first check whether the error message is expected to be used as described above.