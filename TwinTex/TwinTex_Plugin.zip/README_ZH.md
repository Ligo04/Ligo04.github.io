# Twintex

`houdini >=19.5`

## SOP_TwinTex

`C:\Users\xxx\Documents\houdini19.5\dso`目录下：

```
----
 ├──SOP_TwinTex.dll
 ├──libgmp-10.dll
 ├──opencv_world460.dll
```

即可在Geometry节点上添加SOP_TwinTex

![image-20230906162939471](D:\TwinTex\assets\image-20230906162939471.png)

## RUN

1. 首先指定配置文件`default_config.yaml`以及场景目录路径，场景目录结构如下：

   ```
   ----
    ├──Mesh
       ├──original_mesh.ply
       ├──simplify_mesh.ply
       ├──simplify_mesh_sub.ply
    ├──Scene
    ├──Results(自动创建)
   ```

2. 按下`Load Data`按钮加载场景数据

3. (可选)`Load Results` ： 加载`Result\finale_result`的结果

4. (可选) `Show Views`：显示视角的位置与方向(仅在单个平面时候起效果)

5. (可选) `Show Image`：显示ViewSelection或者ImageStitching的输出结果(仅在单个平面时候起效果)

6. `ViewSelection`: ViewSelection的参数与apply

7. `ImageStitching`：ImageStitching的参数与apply

8. `Inpainting`:

   - `MMRP Path`： 指定MMRP项目的路径，依赖详解看这里
   - `Inpainting`:  对某个面或者整个模型进行inpaint
   
9. `start`: ViewSelection 以及 ImageStitching 同时apply

若houdini崩溃，请先检查是否按照上述要求使用

**Copyright©2023 VCC.All rights reserved.**